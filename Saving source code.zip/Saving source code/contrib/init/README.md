Sample configuration files for:
```
SystemD: savingd.service
Upstart: savingd.conf
OpenRC:  savingd.openrc
         savingd.openrcconf
CentOS:  savingd.init
macOS:    org.saving.savingd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
